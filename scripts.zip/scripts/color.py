def color(text):
    return '\033[91m' + text + '\033[0m'
